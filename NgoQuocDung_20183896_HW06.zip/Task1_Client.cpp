#include<winsock2.h>
#include<WS2tcpip.h>
#include <iostream>
#include<string>
#pragma comment(lib,"Ws2_32.lib")
#define BUFF_SIZE 2048
using namespace std;

//Socket variables
//char* SERVER_ADDR;
//int SERVER_PORT;
SOCKET client;
sockaddr_in serverAddr;

//Protocol - Communication variables
string in_data;
string out;
char buff[2048];
string userName, message, header;
char* SERVER_ADDR;
int SERVER_PORT;
int ret, messageLen;

//Control
bool isUser = false;

/* The recv() wrapper function */
int Receive(SOCKET s, char* buff, int size, int flags) {
    in_data = "";
    int n, len = 0;
    bool end = false;
    while (1) {
        n = recv(s, buff, size, flags);
        if (n == SOCKET_ERROR) {
            printf("Error: %d\n", WSAGetLastError());
            break;
        }
        buff[n] = 0;
        len += n;
        in_data += buff;
        for (int j = 1; j < len - 1; j++) {
            if (in_data[j] == '\r' && in_data[j + 1] == '\n') {
                end = true;
                break;
            }
        }
        if (end) break;
    }
    in_data = in_data.substr(0, in_data.length() - 2);
    return n;
}

/* The send() wrapper function*/
int Send(SOCKET s, string buff, int size, int flags) {
    int n, index = 0;
    int rLeft = size;
    while (rLeft > 0) {
        n = send(s, buff.c_str() + index, rLeft, flags);
        if (n == SOCKET_ERROR) {
            printf("Error: %d\n", WSAGetLastError());
            break;
        }
        rLeft -= n;
        index += n;

    }
    return n;
}

/* The login function send login request to server
* @param No param
* @return True if logged in
*/
bool login() {
    string command;
    header = "LOGIN ";
    while (1) {
        cout << "1. (Input 1) Enter username " << endl;
        cout << "2. (Input 2) Back to main menu" << endl;
        cout << "Input: ";
        getline(cin, command);
        if (command == "2")
            return false;
        if (command != "1") {
            cout << "Wrong input!" << endl;
            continue;
        }
        cout << "Your username: ";
        /*cin >> userName;*/
        getline(cin, userName);
        out = "";
        out += header + userName + "\r\n";
        messageLen = out.length();
        ret = Send(client, out, messageLen, 0);
        if (ret == SOCKET_ERROR) {
            cout << "Failed to send username to server: Error " << WSAGetLastError() << endl;
        }
        else if (ret == 0) {
            cout << "Please enter a valid username" << endl;
        }
        else {
            ret = Receive(client, buff, BUFF_SIZE, 0);
            if (ret == SOCKET_ERROR)
                cout << "Failed to receive feedback from server: Error " << WSAGetLastError() << endl;
            else {
                if (in_data == "100") {
                    //Return code 100: Success
                    cout << "Signed in! Back to main menu..." << endl;
                    return true;
                }
                else if (in_data == "101") {
                    //Return code 101: Not found
                    cout << "Invalid ID" << endl;
                }
                else if (in_data == "102") {
                    //Return code 102: Currently signed in
                    cout << "Your account is already signed in another client" << endl;
                }
                else if (in_data == "103") {
                    //Return code 103: Account locked
                    cout << "Account currently suspended" << endl;
                }
                else if (in_data == "104") {
                    //Return code 104: Already logged in
                    cout << "You are already logged in" << endl;
                }
            }
        }
    }
}

/* The postMess function send message request to server
* @param No param
* @return No return value
*/
void postMess() {
    string command;
    header = "MESS  ";
    while (1) {
        cout << "1. (Input 1) Send to server: " << endl;
        cout << "2. (Input 2) Back to main menu" << endl;
        cout << "Input: ";
        getline(cin, command);
        if (command == "2")
            return;
        if (command != "1") {
            cout << "Wrong input!" << endl;
            continue;
        }
        cout << "Your message: ";
        getline(cin, message);
        out = "";
        out += header + message + "\r\n";
        messageLen = out.length();
        if (messageLen == 0) {
            cout << "Invalid message! Please try again" << endl;
            continue;
        }
        ret = Send(client, out, messageLen, 0);
        if (ret == SOCKET_ERROR) {
            cout << "Error sending data: " << WSAGetLastError() << endl;
        }
        else {
            ret = Receive(client, buff, BUFF_SIZE, 0);
            if (ret == SOCKET_ERROR)
                cout << "Failed to receive feedback from server: Error " << WSAGetLastError() << endl;
            else {
                if (in_data == "200") {
                    //Return code 200: Success
                    cout << "Message delivered" << endl;
                }
                else if (in_data == "201")
                    //Return code 201: Not logged in
                    cout << "You are not logged in" << endl;
                else
                    cout << "Wrong response" << endl;
            }
        }
    }
}

/* The logOut function send log out request to server
* @param No param
* @return No return value
*/
void logOut() {
    header = "LOGOUT\r\n";
    messageLen = header.length();
    ret = Send(client, header, messageLen, 0);
    if (ret == SOCKET_ERROR)
        cout << "Error sending request: " << WSAGetLastError() << endl;
    else {
        ret = Receive(client, buff, BUFF_SIZE, 0);
        if (ret == SOCKET_ERROR)
            cout << "Failed to receive feedback from server: Error " << WSAGetLastError() << endl;
        else {
            if (in_data == "300")
                //Return code 300: Success
                cout << "Logged out successful" << endl;
            else if (in_data == "301")
                //Return code 201: Not logged in
                cout << "You are not logged in" << endl;
            else
                cout << "Wrong response" << endl;
        }
    }
}

/* The quit function send quit request to server
* @param No param
* @return No return value
*/
void quit() {
    header = "QUIT  \r\n";
    messageLen = header.length();
    ret = Send(client, header, messageLen, 0);
    if (ret == SOCKET_ERROR)
        cout << "Error sending request: " << WSAGetLastError() << endl;
    else {
        ret = Receive(client, buff, BUFF_SIZE, 0);
        if (ret == SOCKET_ERROR)
            cout << "Failed to receive feedback from server: Error " << WSAGetLastError() << endl;
        else {
            if (in_data == "400")
                //Return code 400: Success
                cout << "Quit successful" << endl;
            else
                cout << "Wrong response" << endl;
        }
    }
}

/*The showMenu function display user interface and call appropriate function
* @param No param
* @return False if user choose exit
*/
bool showMenu() {
    string command;
    cout << "1. Log in" << endl;
    cout << "2. Post Message" << endl;
    cout << "3. Logout" << endl;
    cout << "4. Exit" << endl;
    cout << "Input: ";
    getline(cin, command);
    if (command != "1" && command != "2" && command != "3" && command != "4") {
        cout << "Wrong input!" << endl;
        return true;
    }
    switch (stoi(command)) {
    case 1:
        login();
        break;
    case 2:
        postMess();
        break;
    case 3:
        logOut();
        break;
    case 4:
        quit();
        return false;
        //Break loop
    }
    return true;
    // Keep looping until quit
}

int main(int argc, char* argv[]) {
    //Command line variables
    SERVER_ADDR = argv[1];
    SERVER_PORT = stoi(argv[2]);

    //Initialize winsock2
    WSAData wsaData;
    WORD wVersion = MAKEWORD(2, 2);
    if (WSAStartup(wVersion, &wsaData)) {
        cout << "Failed to start ws2" << endl;
        return 0;
    }
    //Step 2: Construct socket
    client = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    //Step 3: Specify server address
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_ADDR, &serverAddr.sin_addr);

    //Step 4: Request to connect server
    if (connect(client, (sockaddr*)&serverAddr, sizeof(serverAddr))) {
        cout << "Error! Cannot connect server." << endl;
        return 0;
    }

    //Step 5: Communicate with server
    while (showMenu()) {
        //Nothing
    }

    //Step 6: Close socket
    closesocket(client);

    //Step 7: Terminate Winsock
    WSACleanup();
}