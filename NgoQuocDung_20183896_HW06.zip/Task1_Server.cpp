// WSAEventSelectServer.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <conio.h>
#include <WinSock2.h>
#include<WS2tcpip.h>
#include<string>
#include<iostream>
#include<fstream>
#pragma comment(lib, "Ws2_32.lib")

using namespace std;

#define PORT 6000
#define BUFF_SIZE 2048
#define SERVER_ADDR "127.0.0.1"

struct SESSION {
	SOCKET conn_socket;
	char client_ip[INET_ADDRSTRLEN];
	int client_port;
	string account;
	bool loggedIn;
};

SESSION session[WSA_MAXIMUM_WAIT_EVENTS];
int clientPort;
char clientIP[INET_ADDRSTRLEN];

string in_data; //protocol
string header, body;
string usr[10]; //account array

//To generate time format
time_t rawtime;
tm* timeinfo;
char buffer[80];


void processData(string, int);
int Receive(SOCKET, char*, int, int, int);
int Send(SOCKET, string, int, int, int);
void checkLogin(string, int);
void checkMess(string, int);
void checkLogout(int);
void checkQuit(int);

int main(int argc, char* argv[])
{
	DWORD		nEvents = 0;
	DWORD		index;
	SOCKET		socks[WSA_MAXIMUM_WAIT_EVENTS];
	WSAEVENT	events[WSA_MAXIMUM_WAIT_EVENTS];
	WSANETWORKEVENTS sockEvent;

	//Step 1: Initiate WinSock
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData)) {
		printf("Winsock 2.2 is not supported\n");
		return 0;
	}

	//Step 2: Construct LISTEN socket	
	SOCKET listenSock;
	listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	//Step 3: Bind address to socket
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	inet_pton(AF_INET, SERVER_ADDR, &serverAddr.sin_addr);

	socks[0] = listenSock;
	events[0] = WSACreateEvent(); //create new events
	nEvents++;

	//Get account 
	ifstream indata;
	indata.open("account.txt");
	if (!indata.is_open()) { // file couldn't be opened
		cout << "Error: file could not be opened" << endl;
		exit(1);
	}
	int i = 0;
	indata >> usr[i];
	while (!indata.eof()) {
		i++;
		indata >> usr[i];
	}
	indata.close();

	// Associate event types FD_ACCEPT and FD_CLOSE
	// with the listening socket and newEvent   
	WSAEventSelect(socks[0], events[0], FD_ACCEPT | FD_CLOSE);


	if (bind(listenSock, (sockaddr*)&serverAddr, sizeof(serverAddr)))
	{
		printf("Error %d: Cannot associate a local address with server socket.", WSAGetLastError());
		return 0;
	}

	//Step 4: Listen request from client
	if (listen(listenSock, 10)) {
		printf("Error %d: Cannot place server socket in state LISTEN.", WSAGetLastError());
		return 0;
	}

	printf("Server started!\n");

	char sendBuff[BUFF_SIZE], recvBuff[BUFF_SIZE];
	SOCKET connSock;
	sockaddr_in clientAddr;
	int clientAddrLen = sizeof(clientAddr);
	int ret, end = 0;

	for (int i = 1; i < WSA_MAXIMUM_WAIT_EVENTS; i++) {
		socks[i] = 0;
	}
	while (1) {
		//wait for network events on all socket
		index = WSAWaitForMultipleEvents(nEvents, events, FALSE, WSA_INFINITE, FALSE);
		if (index == WSA_WAIT_FAILED) {
			printf("Error %d: WSAWaitForMultipleEvents() failed\n", WSAGetLastError());
			break;
		}

		index = index - WSA_WAIT_EVENT_0;
		WSAEnumNetworkEvents(socks[index], events[index], &sockEvent);

		if (sockEvent.lNetworkEvents & FD_ACCEPT) {
			if (sockEvent.iErrorCode[FD_ACCEPT_BIT] != 0) {
				printf("FD_ACCEPT failed with error %d\n", sockEvent.iErrorCode[FD_READ_BIT]);
				break;
			}

			if ((connSock = accept(socks[index], (sockaddr*)&clientAddr, &clientAddrLen)) == SOCKET_ERROR) {
				printf("Error %d: Cannot permit incoming connection.\n", WSAGetLastError());
				break;
			}

			//Add new socket into socks array
			/*int i;*/
			if (nEvents == WSA_MAXIMUM_WAIT_EVENTS) {
				printf("\nToo many clients.");
				closesocket(connSock);
			}
			else if (end + 1 < WSA_MAXIMUM_WAIT_EVENTS) {
				/*for (i = 1; i < WSA_MAXIMUM_WAIT_EVENTS; i++)
					if (socks[i] == 0) {
						socks[i] = connSock;
						events[i] = WSACreateEvent();
						WSAEventSelect(socks[i], events[i], FD_READ | FD_CLOSE);
						nEvents++;
						break;
					}*/
				inet_ntop(AF_INET, &clientAddr, clientIP, sizeof(clientIP));
				clientPort = ntohs(clientAddr.sin_port);
				cout << "You got a connection from [" << clientIP << ":" << clientPort << "]" << endl;
				end++;
				socks[end] = connSock;
				events[end] = WSACreateEvent();
				WSAEventSelect(socks[end], events[end], FD_READ | FD_CLOSE);
				session[end].conn_socket = connSock;
				strcpy(session[end].client_ip, clientIP);
				session[end].client_port = clientPort;
				session[end].loggedIn = false;
				nEvents++;
			}

			//reset event
			WSAResetEvent(events[index]);
		}

		if (sockEvent.lNetworkEvents & FD_READ) {
			//Receive message from client
			if (sockEvent.iErrorCode[FD_READ_BIT] != 0) {
				printf("FD_READ failed with error %d\n", sockEvent.iErrorCode[FD_READ_BIT]);
				break;
			}

			ret = Receive(socks[index], recvBuff, BUFF_SIZE, 0, index);

			//Release socket and event if an error occurs
			if (ret <= 0) {
				closesocket(socks[index]);
				//socks[index] = 0;
				WSACloseEvent(events[index]);
				socks[index] = socks[end];
				socks[end] = 0;
				events[index] = events[end];
				session[index] = session[end];
				if (end > 0)
					end--;
				nEvents--;
			}
			else {
				//Logging
				fstream outdata;
				outdata.open("log_20183896.txt", fstream::app);

				//Process request
				processData(in_data, index);

				//Get time
				time(&rawtime);
				timeinfo = localtime(&rawtime);
				strftime(buffer, 80, "%Y-%m-%d-%H-%M-%S", timeinfo);
				puts(buffer);

				//Write log
				outdata << session[index].client_ip << ":" << session[index].client_port << " [" << buffer << "] $ " << in_data.substr(0, in_data.length() - 2) << " $ " << header.substr(0, 3) << endl;
				outdata.close();
				//Send return code
				Send(socks[index], header, header.length(), 0, index);

				//reset event
				WSAResetEvent(events[index]);
			}
		}

		if (sockEvent.lNetworkEvents & FD_CLOSE) {
			if (sockEvent.iErrorCode[FD_CLOSE_BIT] != 0) {
				printf("FD_CLOSE failed with error %d [%s:%d]\n", sockEvent.iErrorCode[FD_CLOSE_BIT], session[index].client_ip, session[index].client_port);
				//break;
			}
			//Release socket and event
			closesocket(socks[index]);
			//socks[index] = 0;
			WSACloseEvent(events[index]);
			socks[index] = socks[end];
			socks[end] = 0;
			events[index] = events[end];
			session[index] = session[end];
			if (end > 0)
				end--;
			nEvents--;
		}
	}
	return 0;
}

/* The processData function process client's request and call appropriate function
* @param in Pointer to input string
* @return No return value
*/
void processData(string in, int sess) {
	header = "";
	body = "";
	header = in.substr(0, 6);

	//check header
	if (header == "LOGIN ") {
		cout << "Checking login" << endl;
		checkLogin(in, sess);
	}
	else if (header == "MESS  ") {
		cout << "Checking message" << endl;
		checkMess(in, sess);
	}
	else if (header == "LOGOUT") {
		cout << "Checking logout" << endl;
		checkLogout(sess);
	}
	else if (header == "QUIT  ") {
		cout << "Checking quit" << endl;
		checkQuit(sess);
	}
	header += "\r\n";
}

/*Function to process login request and edit header (return code)
* @param in Pointer to input string
* @param in Index to the login state of current client
* @return No return value
*/
void checkLogin(string buf, int sess) {
	//Get body
	body = buf.substr(6, buf.length() - 8);

	//Check account state
	if (session[sess].loggedIn == true) {
		//Already logged in
		header = "104";
		return;
	}

	//Compare
	for (int i = 0; i <= 6; i += 2)
		if (body == usr[i]) {
			if (usr[i + 1] == "0") {
				//Success
				header = "100";
				/*loggedIn[sess] = true;*/
				session[sess].account = usr[i];
				session[sess].loggedIn = true;
				return;
			}
			else if (usr[i + 1] == "1") {
				//Locked
				header = "103";
				return;
			}
			else if (usr[i + 1] == "2") {
				//Logged in
				header = "102";
			}
		}
	//Not found
	header = "101";
	return;
}

/*Function to process message request and edit header (return code)
* @param in Pointer to input string
* @param in Index to the login state of current client
* @return No return value
*/
void checkMess(string in, int sess) {
	if (session[sess].loggedIn)
		//Success
		header = "200";
	else
		//Not logged in
		header = "201";
	return;
}

/*Function to process log out request and edit header (return code)
* @param in Index to the login state of current client
* @return No return value
*/
void checkLogout(int sess) {
	if (session[sess].loggedIn) {
		//Success
		session[sess].loggedIn = false;
		header = "300";
	}
	else
		//Not logged in
		header = "301";
	return;
}

/*Function to process quit request and edit header (return code)
* @param in Index to the login state of current client
* @return No return value
*/
void checkQuit(int sess) {
	if (session[sess].loggedIn)
		session[sess].loggedIn = false;
	header = "400";
	return;
}

/* The recv() wrapper function */
int Receive(SOCKET s, char* buff, int size, int flags, int sess) {
	in_data = "";
	int n, len = 0;
	bool end = false;
	while (1) {
		n = recv(s, buff, size, flags);
		if (n == SOCKET_ERROR) {
			printf("Error: %d\n", WSAGetLastError());
			break;
		}
		buff[n] = 0;
		len += n;
		in_data += buff;
		for (int j = 1; j < len - 1; j++) {
			if (in_data[j] == '\r' && in_data[j + 1] == '\n')
				end = true;
		}
		if (end) break;
	}
	cout << "Receive from client [" << session[sess].client_ip << ":" << session[sess].client_port << "] : " 
		<< in_data.substr(0, in_data.length() - 2) << endl;

	return n;
}

/* The send() wrapper function*/
int Send(SOCKET s, string buff, int size, int flags, int sess) {
	int n, index = 0;
	int rLeft = size;
	while (rLeft > 0) {
		n = send(s, buff.c_str() + index, rLeft, flags);
		if (n == SOCKET_ERROR) {
			printf("Error: %d\n", WSAGetLastError());
			break;
		}
		rLeft -= n;
		index += n;

	}
	cout << "Send to client [" << session[sess].client_ip << ":" << session[sess].client_port << "] : " 
		<< buff.substr(0,3) << endl;

	return n;
}